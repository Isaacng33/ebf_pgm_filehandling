#include "imagedata.h"

unsigned int ** make2dArr(int height, int width);

int arrCheck(Imagedata * imageData);